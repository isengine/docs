<?php defined('isENGINE') or die;

if (!empty($template -> script)) {
	echo $template -> script;
}

?>