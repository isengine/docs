<?php defined('isENGINE') or die; ?>
<hr>
<p><?= $lang -> common -> nopage; ?></p>
<hr>