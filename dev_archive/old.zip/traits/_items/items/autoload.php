<?php defined('isENGINE') or die;

page('header', 'html');
page('routing', 'item');
page('footer', 'html');

?>