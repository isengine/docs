<?php defined('isENGINE') or die;

case 'home'    : $data['data'] = ''; break;
case 'group'   : $data['data'] = ''; break;
case 'nolink'  : $data['data'] = ''; break;
case 'none'    : $data['data'] = '#'; break;
case 'hash'    : $data['data'] = $data['base'] . '#' . $data['name']; break;
case 'action'  : $data['data'] = '#' . $data['name']; break;
case 'url'     : $data['data'] = $data['data']; break;
case 'int'     : $data['data'] = $data['base'] . $data['data'] . '.'; break;
default        : $data['data'] = $data['base'] . $data['name'] . '.'; break;

?>